-- Show all students
SELECT * FROM Students;

-- Show all courses
SELECT * FROM Courses;

-- Show enrollments with student and course names
SELECT s.name AS Student, c.course_name AS Course
FROM Enrollments e
JOIN Students s ON e.student_id = s.student_id
JOIN Courses c ON e.course_id = c.course_id;

-- Show students not enrolled in any course
SELECT s.name
FROM Students s
LEFT JOIN Enrollments e ON s.student_id = e.student_id
WHERE e.enrollment_id IS NULL;

-- Show courses with no students enrolled
SELECT c.course_name
FROM Courses c
LEFT JOIN Enrollments e ON c.course_id = e.course_id
WHERE e.enrollment_id IS NULL;

-- Count students enrolled in each course
SELECT c.course_name, COUNT(e.student_id) AS total_students
FROM Courses c
LEFT JOIN Enrollments e ON c.course_id = e.course_id
GROUP BY c.course_name;

-- List students and how many courses they’re enrolled in
SELECT s.name AS Student, COUNT(e.course_id) AS Total_Courses
FROM Students s
LEFT JOIN Enrollments e ON s.student_id = e.student_id
GROUP BY s.name;

-- Students enrolled in more than one course
SELECT s.name, COUNT(e.course_id) AS Courses_Enrolled
FROM Students s
JOIN Enrollments e ON s.student_id = e.student_id
GROUP BY s.name
HAVING COUNT(e.course_id) > 1;
