-- ------------------------
-- Insert data into Students
-- ------------------------
INSERT INTO Students (student_id, name, email) VALUES
(1, 'Alice Johnson', 'alice@example.com'),
(2, 'Bob Smith', 'bob@example.com'),
(3, 'Charlie Davis', 'charlie@example.com');

-- ------------------------
-- Insert data into Courses
-- ------------------------
INSERT INTO Courses (course_id, course_name, instructor) VALUES
(101, 'Database Systems', 'Dr. Smith'),
(102, 'Computer Networks', 'Prof. Allen'),
(103, 'Operating Systems', 'Dr. Lee');

-- ------------------------
-- Insert data into Enrollments
-- ------------------------
INSERT INTO Enrollments (enrollment_id, student_id, course_id) VALUES
(1, 1, 101),
(2, 2, 101),
(3, 2, 102),
(4, 3, 102),
(5, 1, 103);
