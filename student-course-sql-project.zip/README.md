# 📚 Student Course Management System (SQL Project)

This is a simple SQL-based project for managing students, courses, and enrollments. It helps understand relational databases using MySQL.

## 🛠️ Tech Stack
- MySQL (Tested on version 8.x)
- SQL (DDL, DML, JOINs)
- Git & GitHub

## 📁 Folder Structure
```
student-course-sql-project/
├── schema.sql      -- SQL commands to create tables
├── data.sql        -- Sample data to populate the database
├── queries.sql     -- Useful SQL queries for reporting
└── README.md       -- Project documentation
```

## 🚀 How to Run

1. Install [MySQL](https://dev.mysql.com/downloads/)
2. Open MySQL Workbench or command line
3. Run the following in order:
   ```sql
   SOURCE path/to/schema.sql;
   SOURCE path/to/data.sql;
   SOURCE path/to/queries.sql;
   ```

## 📊 Example Query & Output

```sql
-- Show all enrollments with student and course names
SELECT s.name, c.course_name
FROM Enrollments e
JOIN Students s ON e.student_id = s.student_id
JOIN Courses c ON e.course_id = c.course_id;
```

| Student | Course             |
|---------|--------------------|
| Alice   | Database Systems   |
| Bob     | Database Systems   |
| Bob     | Computer Networks  |
| Charlie | Computer Networks  |

## 👤 Author

- **Your Name**
- GitHub: [@yourusername](https://github.com/yourusername)

## 🙏 Acknowledgements

Inspired by database labs and academic projects.
